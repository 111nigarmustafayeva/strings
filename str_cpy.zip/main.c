/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

//string-in copisi
int main()
{
   char str1[]="Hello";
   int x=sizeof(str1);
   char a[]="";
   for(int i=0;i < x;i++){
       a[i]=str1[i];
   }
  printf("%s",a);

    return 0;
}

